from flask import Flask, jsonify, Response, request
import json

#プロダクトのカテゴリ保持リスト
asgdict={}

app = Flask(__name__)

#ドメインid
@app.route('/apis/domains/', methods=['GET'])
def domains():
    securityboss    = 5

    domain_name = request.args.get('name')
    res = [
            {
                "id": securityboss,
                "name": "securityboss",
            }
    ]
    return jsonify(results=res)


#カテゴリid
@app.route('/apis/categories/', methods=['GET'])
def categories():
#     return jsonify(request.url)
# #    return jsonify(request.full_path)



#    return jsonify(request.data)
#    return jsonify(str(request.values.get('domain', 'name')))    

#    all_args = request.args
#    return jsonify(all_args)

    # domain_id = request.args.get['domain']
    category_name = request.args.get('name')

    categorylist = {
        'asg_alert':9,
        'asg_unwatched':8,
        'asg_watch':7,
    }
    return jsonify(results=[{'id':categorylist[category_name]}])

# #    return jsonify(results=[{'domain_id':domain_id,'category_name':category_name}])
#     return jsonify(results=[{'args':args}])

#プロダクトid 渡されたセンター名をそのまま返す
@app.route('/apis/products/', methods=['GET'])
def products():
    product_name = request.args.get('name')

    print(product_name)
    if product_name == 'asg_err':
        response = Response()
        response.status_code = 400
        return response

    # return jsonify(results=[{'id':product_name}])

    products = {
        'asg_001':1,
        'asg_002':2,
        'asg_003':3,
        'asg_004':4,
        'asg_005':5,
        'asg_006':6,
        'asg_999':999,
        'astaro_v2':102,
        'astaro_v4':103,
        'astaro_v5':105,
        'astaro_v6':106,
        'astaro_v7':107,
        'astaro_v8':108,
        'astaro_v9':109,
        'astaro_v10':110,
        'astaro_v11':111,
        'astaro_v12':112,
        'astaro_v13':113,
        'astaro_v14':114,
        'astaro_v15':115,
        'astaro_v16':116,
        'astaro_v17':117,
        'astaro_v18':118,
        'astaro_v19':119,
        'astaro_v20':120,
        'astaro_v21':121,
        'astaro_v22':122,
        'astaro_v23':123,
        'astaro_v24':124,
        'astaro_v25':125,
        'astaro_v26':126,
        'astaro_v27':127,
        'astaro_v28':128,
        'astaro_v29':129,
        'astaro_v30':130,
        'astaro_v31':131,
        'astaro_v32':132,
        'astaro_v33':133,
        'astaro_v34':134,
        'astaro_v35':135,
        'astaro_v36':136,
        'sboss_gss-astaro_v10':137,
        'sboss_gss-astaro_v11':138,
        'sboss_gss-astaro_v12':139,
        'sboss_gss-astaro_v13':140,
        'sboss_gss-astaro_v14':141,
        'sboss_gss-astaro_v15':142,
        'sboss_gss-astaro_v16':143,
        'sboss_gss-astaro_v17':144,
        'sboss_gss-astaro_v18':145,
        'sboss_gss-astaro_v19':146,
        'sboss_gss-astaro_v2':147,
        'sboss_gss-astaro_v20':148,
        'sboss_gss-astaro_v21':149,
        'sboss_gss-astaro_v22':150,
        'sboss_gss-astaro_v23':151,
        'sboss_gss-astaro_v24':152,
        'sboss_gss-astaro_v25':153,
        'sboss_gss-astaro_v26':154,
        'sboss_gss-astaro_v27':155,
        'sboss_gss-astaro_v28':156,
        'sboss_gss-astaro_v29':157,
        'sboss_gss-astaro_v30':158,
        'sboss_gss-astaro_v31':159,
        'sboss_gss-astaro_v32_v9':160,
        'sboss_gss-astaro_v33':161,
        'sboss_gss-astaro_v34':162,
        'sboss_gss-astaro_v35':163,
        'sboss_gss-astaro_v36':164,
        'sboss_gss-astaro_v4':165,
        'sboss_gss-astaro_v5':166,
        'sboss_gss-astaro_v6':167,
        'sboss_gss-astaro_v7':168,
        'sboss_gss-astaro_v8':169,
        'sboss_gss-astaro_v9':170,

    }
    return jsonify(results=[{'id':products[product_name]}])


#プロダクト更新 カテゴリのみ、その他はプロダクトID埋め込み
@app.route('/apis/products/<id>/', methods=['PATCH'])
def products_category_update(id):
#    category = request.args.get('category')
    json = request.get_json() 
    category = json['category']
    asgdict[id] = category
  #  return jsonify(id)

    results = {
        "id": id,
        "category": category,
        "name": id,
        "descri": id,
    }
    return jsonify(results)

@app.route('/apis/products_all', methods=['GET'])
def products_all():
    return jsonify(asgdict)

#監視結果の判定
@app.route('/apis/anomalies_value/', methods=['POST'])
def anomalies_value():
    json = request.get_json() 
    product_id = json['product']
    success = json['success']
    failure = json['failure']

    response = category_judge(success,failure)
    return jsonify(response)

#監視結果登録
@app.route('/apis/anomalies/', methods=['POST'])
def anomalies():
    json = request.get_json()
    product_id = str(json['product'])

#    data = request.data.decode('utf-8')
#    data = json.loads(data)

    if product_id == '999':
        response =  Response()
        response.status_code = 400
        return response
    else:
        success = json['success']
        failure = json['failure']
        if asgdict[product_id] ==  category_judge(success,failure):
            response =  Response()
            response.status_code = 201
            return response

    return jsonify({'message': 'request params are invalid.', 'req': json, 'category': asgdict[product_id]}), 400

def category_judge(success,failure):
    if success == 0 and failure == 0 :
        return 8 
    elif success == 0 :
        return 9
    return 7



# def anomalies():
#   normal      = 7
#   nothing     = 8
#   all_failure = 9
  
#   requests = request.get_json()
#   for req in requests:
#       category = __get_category_from(req['product'])
#       if (category == normal and not __ping_result_is_normal(req)) or
#           (category == nothing and not __ping_result_is_nothing(req)) or
#           (category == all_failure and not __ping_result_is_all_failure(req)):
#           return jsonify({'message': 'request params are invalid.', 'req': req}), 400
#       else:
#           response =  Response()
#           response.status_code = 201
#           return response
          
# def __ping_result_is_normal(req):
#     req['success'] > 0 and req['failure'] >= 0

# def __ping_result_is_nothing(req):
#     req['success'] == 0 and req['failure'] == 0

# def __ping_result_is_all_failure(req):
#     req['success'] == 0 and req['failure'] > 0

# def __get_categor_from(product):
#    return response
