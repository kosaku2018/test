import pandas as pd
import os
import ipaddress
from paramiko import SSHClient, AutoAddPolicy


class TestLibrary(object):


    def is_valid_ipaddress(self, ip_address):
        try:
            ipaddress.IPv4Address(ip_address)
            return True
        except ipaddress.AddressValueError:
            return False


    def check_pinglist(self, gss_list_path, pinglist_path, cacti_indir_path, exp_cnt):
        # Read df_pinglist file
        exp_cnt = int(exp_cnt)
        list_gss = [line.rstrip('\n') for line in open(gss_list_path)]
        
        df_pinglist = pd.read_csv(pinglist_path)
        df_pinglist.fillna(value='', inplace=True)
        list_ping = df_pinglist['asgname'].tolist()

        # asg list in gss.lst and asg names in pinglist must be the same
        if not set(list_gss) == set(list_ping):
            return False

        for asgname in list_gss:
            df_group = df_pinglist[df_pinglist['asgname'] == asgname].copy()

            # Create a list of IP addresses from pinglist file, without duplicates
            pinglist_list = list(set([x for x in df_group['ip_address'].tolist() if len(str(x).rstrip()) != 0]))
            pinglist_cnt = len(pinglist_list)

            cacti_file_cnt = 0
            cacti_file_path = os.path.join(cacti_indir_path, asgname + ".log")

            if os.path.isfile(cacti_file_path):
                # Open input file if it exists and create a list of IP addresses.
                df = pd.read_csv(cacti_file_path, sep=',', header=None, names=['ip_address', 'hostname', 'ip_and_port', 'datetime'])

                # Remove invalid IP addresses
                df_ipcheck = df[['ip_address']].copy().drop_duplicates()
                df_ipcheck['is_valid'] = [self.is_valid_ipaddress(x) for x in df_ipcheck['ip_address']]
                df_cacti_file = df_ipcheck[df_ipcheck['is_valid'] == True].copy()
                df_cacti_file.drop(columns='is_valid', inplace=True)

                cacti_file_ip_list = list(set(df_cacti_file['ip_address'].tolist()))
                cacti_file_cnt = len(cacti_file_ip_list)

                # check if ip addresses in pinglist exists in cacti file ip list
                if pinglist_cnt > 0:
                    # Return False if IP address from pinglist does not exist in input file
                    for ip_address in pinglist_list:
                        if ip_address not in cacti_file_ip_list:
                            return False

            # If line count is greater than or equal to exp_cnt, then pinglist count should be equal to exp_cnt
            if (cacti_file_cnt >= exp_cnt) and (pinglist_cnt == exp_cnt):
                continue
            # If line count is lesser than exp_cnt, then pinglist count should be equal to line count
            elif (cacti_file_cnt < exp_cnt) and (pinglist_cnt == cacti_file_cnt):
                continue
            else:
                return False

        return True


    def is_pinglist_diff(self, old_pinglist_path, new_pinglist_path, asg_filter=None):
        df1 = pd.read_csv(old_pinglist_path)
        df1.fillna(value='', inplace=True)
        df2 = pd.read_csv(new_pinglist_path)
        df2.fillna(value='', inplace=True)

        if asg_filter is not None:
            df1 = df1[df1['asgname'] == asg_filter].copy()
            df2 = df2[df2['asgname'] == asg_filter].copy()

        df_merged = df1.merge(df2, indicator=True, how='outer')
        if len(df_merged) == len(df_merged[df_merged['_merge'] == 'both']):
            return False

        return True
