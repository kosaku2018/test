import glob
import filecmp
def logfiles_should_be_the_same(ASG_path, ASG_copied_path):
    """
    You compare　 two files(csv) and if they are the same, return true.

    Parameters
    ----------
    count : int
    It is the index to judge the result.
    If it isn't 0, this method judge that the two files are not the same.
            
    Returns
    -------
    True
    It means the two files are the same.
    False
    It means the two files are not the same.
    """
    ASG_filepath_list = sorted(glob.glob(ASG_path))
    ASG_copied_filepath_list = sorted(glob.glob(ASG_copied_path))
    count = 0 
    ASG_filename = [r.split('/')[-1] for r in ASG_filepath_list]   
    ASG_copied_filename = [r.split('/')[-1] for r in ASG_copied_filepath_list]
    if ASG_filename != ASG_copied_filename:
        count += 1
    for i in range(len(ASG_filepath_list)):
        result = filecmp.cmp(ASG_filepath_list[i], ASG_copied_filepath_list[i])
        if result == False:
            count += 1
    if count == 0:
        return True
    else:
        return False
