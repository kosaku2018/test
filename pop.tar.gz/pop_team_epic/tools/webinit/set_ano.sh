#!/bin/bash

#usage,no argument
if [ $# -eq 0 ]; then
  echo "Usage: ./set_ano.sh \"https://securityboss.p.officialreport.net\" \"sboss_gss-astaro_v10\" 10 10" 1>&2
  exit 1
fi

URL=$1
ASG_NAME=$2

PID=$(curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id')
echo "pid:"$PID
#echo curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id'


DD=$(date '+%Y-%m-%dT%T')
#PID=58
SUCCESS=$3
FAILURE=$4

#curl -v -X POST -H "Content-Type: application/json" -d '{"product":'$PID',"datetime":"'$DD'","success":'$SUCCESS',"failure":'$FAILURE'}' $URL/apis/anomalies/
curl --dump-header - -X POST -H "Content-Type: application/json" -d '{"product":'$PID',"datetime":"'$DD'","success":'$SUCCESS',"failure":'$FAILURE'}' $URL/apis/anomalies/
 