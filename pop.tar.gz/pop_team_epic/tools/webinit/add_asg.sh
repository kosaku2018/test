#!/bin/bash

CMDNAME=`basename $0`

while getopts e:d:f: OPT
do
  case $OPT in
    "d" ) FLG_D="TRUE" ; VALUE_A="$2" VALUE_B="$3" VALUE_C="$4" VALUE_D="$5";;
    "e" ) FLG_E="TRUE" ; VALUE_A="$2" VALUE_B="$3" ;;
    "f" ) FLG_F="TRUE" ; VALUE_A="$2" VALUE_B="$3" ;;
      * ) echo "Usage: $CMDNAME [-d] [url] [カテゴリ] [ASG名] [DESCRI]" 1>&2
          echo "Usage: $CMDNAME [-e] [url] [ASGファイル]" 1>&2
          echo "Usage: $CMDNAME [-f] [urlファイル] [ASGファイル]" 1>&2
          exit 1 ;;
  esac
done


if [ "$FLG_D" = "TRUE" ]; then

  URL=$VALUE_A
  ASG_CATE=$VALUE_B
  ASG_NAME=$VALUE_C
  ASG_DESC=$VALUE_D

   curl --dump-header - -X POST -H "Content-Type: application/json" -d '{"category": '$ASG_CATE', "name": "'$ASG_NAME'", "descr": "'$ASG_DESC'"}' $URL/apis/products/

fi


if [ "$FLG_E" = "TRUE" ]; then

  URL=$VALUE_A
  FILE_ASG=$VALUE_B

  while read row; do

    ASG_CATE=`echo ${row} | cut -d , -f 1`
    ASG_NAME=`echo ${row} | cut -d , -f 2`
    ASG_DESC=`echo ${row} | cut -d , -f 3`

    curl --dump-header - -X POST -H "Content-Type: application/json" -d '{"category": '$ASG_CATE', "name": "'$ASG_NAME'", "descr": "'$ASG_DESC'"}' $URL/apis/products/

  done < $FILE_ASG

fi

if [ "$FLG_F" = "TRUE" ]; then

  URL=$(cat $VALUE_A)
  FILE_ASG=$VALUE_B

  while read row; do

    ASG_CATE=`echo ${row} | cut -d , -f 1`
    ASG_NAME=`echo ${row} | cut -d , -f 2`
    ASG_DESC=`echo ${row} | cut -d , -f 3`

    curl --dump-header - -X POST -H "Content-Type: application/json" -d '{"category": '$ASG_CATE', "name": "'$ASG_NAME'", "descr": "'$ASG_DESC'"}' $URL/apis/products/

  done < $FILE_ASG

fi

exit 0
