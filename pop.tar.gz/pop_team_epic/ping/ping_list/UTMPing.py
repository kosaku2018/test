#!/usr/bin/env python

import os
import sys
import yaml
import pandas as pd
import logging
import ipaddress
from datetime import datetime
from glob import glob
from paramiko import SSHClient, AutoAddPolicy


class UTMPing():

    # init class-scope variables
    def __init__(self, conf_path):
        self.set_variables(self.read_config(conf_path))

        if not os.path.isdir(self.indir_cacti):
            os.mkdir(self.indir_cacti)
        if os.path.isfile(self.out_pnglst):
            os.remove(self.out_pnglst)

        self.log = self.init_log()

    # Read configuration file, return as dictionary of values
    def read_config(self, conf_path):
        if not os.path.isfile(conf_path):
            raise ValueError("Settings file: {}  does not exist.".format(conf_path))
        with open(conf_path, 'r') as yaml_file:
            return yaml.safe_load(yaml_file)

    # Set instance variables from config dictionary
    def set_variables(self, conf):
        self.host  = conf['remote_host']
        self.port = conf['remote_port']
        self.user = conf['remote_user']
        self.password = conf['remote_password']
        self.src_dir = conf['remote_dir']
        self.src_file = conf['remote_src_file']
        self.timeout = float(conf['timeout'])

        self.gss_lst = conf['gss_lst']
        self.indir_cacti = conf['local_input_dir']
        self.out_pnglst = conf['output_csv_pnglst']

        self.extracount = int(conf['extracount'])
        self.in_file_ext = conf['local_input_file_ext']

        self.log_level = conf['log_level']
        self.log_path = conf['local_log_dir']
        self.log_msg_fmt = conf['log_msg_fmt']
        self.log_date_fmt = conf['log_date_fmt']
        self.log_mode = conf['log_mode']

    def log_and_raise_error(self, err_message):
        self.log.error(err_message)
        raise ValueError(err_message)

    def read_gss_lst(self):
        if not os.path.isfile(self.gss_lst):
            self.log_and_raise_error("GSS list file: {} does not exist.".format(self.gss_lst))
        return [line.rstrip('\n') for line in open(self.gss_lst)]

    def download_cacti_files(self, list_gss):
        self.log.info("START - download_cacti_files")
        ssh = None
        sftp = None

        if len(list_gss) == 0:
            self.log_and_raise_error("GSS list file is empty.")
        elif not os.path.exists(self.indir_cacti):
            self.log_and_raise_error("{} directory does not exist.".format(self.indir_cacti))

        try:
            self.log.info("{}, {}, {}, {}, {}".format(self.host, self.port, self.user, self.password, self.timeout))
            ssh = SSHClient()
            ssh.set_missing_host_key_policy(AutoAddPolicy())
            ssh.connect(self.host, port=self.port, username=self.user, password=self.password, timeout=self.timeout)
            sftp = ssh.open_sftp()
            sftp.chdir(self.src_dir)

            for gss in list_gss:
                remote_file = os.path.join(gss, self.src_file) 
                try:
                    sftp.stat(remote_file)
                    sftp.get(remotepath=remote_file, localpath=os.path.join(self.indir_cacti, gss + self.in_file_ext))
                except IOError as e:
                    self.log.error("{} - {}".format(e, remote_file))
                    continue

        except Exception as e:
            self.log.error(e)
        finally:
            if sftp:
                sftp.close()
            if ssh:
                ssh.close()

        self.log.info("END - download_cacti_files")
        return True

    # Check if IP address is valid
    def is_valid_ipaddress(self, ip_address):
        try:
            ipaddress.IPv4Address(ip_address)
            return True
        except ipaddress.AddressValueError:
            return False

    # Create pinglist
    def pingip_extra(self, list_gss):
        self.log.info("START - pingip_extra")

        if len(list_gss) == 0:
            self.log_and_raise_error("GSS list file is empty.")
        elif not os.path.exists(self.indir_cacti):
            self.log_and_raise_error("{} directory does not exist.".format(self.indir_cacti))
        elif len([x for x in os.listdir(self.indir_cacti) if x.endswith(self.in_file_ext)]) == 0:
            self.log_and_raise_error("{} directory is empty.".format(self.indir_cacti))

        list_df = []
        for gss in list_gss:
            input_file = os.path.join(self.indir_cacti, gss + self.in_file_ext)
            if os.path.isfile(input_file):
                df = pd.read_csv(input_file, sep=',', header=None, names=['ip_address', 'hostname', 'ip_and_port', 'datetime'])

                # Check for invalid IP addresses
                df_ipcheck = df[['ip_address']].copy().drop_duplicates()
                df_ipcheck['is_valid'] = [self.is_valid_ipaddress(x) for x in df_ipcheck['ip_address']]

                list_invalid = [x for x in df_ipcheck[df_ipcheck['is_valid'] == False]['ip_address']]
                for ip_address in list_invalid:
                    self.log.info("Invalid IP Address: {} - {}".format(gss, ip_address))

                # Remove invalid IP addresses
                df = df_ipcheck[df_ipcheck['is_valid'] == True].copy()
                df.drop(columns='is_valid', inplace=True)

                if len(df) == 0:
                    df_rnd_select = pd.DataFrame({'asgname':[gss], 'ip_address':['']})
                    list_df.append(df_rnd_select)
                    continue

                # Select random IP addresses
                df_rnd_select = df.sample(min(len(df), self.extracount))
                df_rnd_select.insert(loc=0, column='asgname', value=gss)
                list_df.append(df_rnd_select)
            else:
                self.log_and_raise_error("ASG file: {} does not exist.".format(input_file))
                break

        df_pinglist = pd.DataFrame(columns=['asgname', 'ip_address'])
        if len(list_df) > 0:
            df_pinglist = pd.concat(list_df)
 
        self.log.info("END - pingip_extra")
        return df_pinglist

    def main(self):
        self.log.info("START - UTM Ping")

        try:
            list_gss = self.read_gss_lst()
            self.download_cacti_files(list_gss)
            self.pingip_extra(list_gss).to_csv(index=False, path_or_buf=self.out_pnglst, encoding='utf_8')
        except Exception as e:
            self.log_and_raise_error(e)

        self.log.info("END - UTM Ping")

    def init_log(self):
        log = logging.getLogger()
        log.setLevel(self.log_level)
        log.handlers = []

        current_date = datetime.today().strftime("%Y-%m-%d")
        log_format = logging.Formatter(self.log_msg_fmt, self.log_date_fmt)
        log_handler = None

        if self.log_mode == "development":
            if not os.path.isdir(self.log_path):
                os.mkdir(self.log_path)
            log_handler = logging.FileHandler(os.path.join(self.log_path, "log_" + current_date + ".log"))
        elif self.log_mode == "production":
            log_handler = logging.StreamHandler(sys.stdout)
        else:
            raise ValueError("Invalid log mode is set.")

        log_handler.setLevel(self.log_level)
        log_handler.setFormatter(log_format)
        log.addHandler(log_handler)

        return log


if __name__ == '__main__':

    try:
        if len(sys.argv) != 2:
            raise ValueError("Execute the script with the settings file path as an argument.")
        config_path = sys.argv[1]
        utm_ping = UTMPing(config_path)
        utm_ping.main()
    except Exception as e:
        raise ValueError(e)
