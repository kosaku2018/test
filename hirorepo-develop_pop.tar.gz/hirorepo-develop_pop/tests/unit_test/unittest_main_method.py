#!/usr/bin/env python
# coding: utf-8

import unittest
from unittest.mock import patch, MagicMock
import main_method
import logging
import os
from datetime import datetime
import pandas as pd
from pandas.util.testing import assert_frame_equal
import requests


class TestPing_Main_method(unittest.TestCase):

    def setUp(self):
        config_path = '/app/tests/unit_test/test_data/settings/unittest_conf.yaml'
        self.logger = main_method.init_log(main_method.read_config(config_path))
        current_date = datetime.today().strftime("%Y-%m-%d")
        log_dir_path = '/app/tests/unit_test/test_data/log'
        self.log_file_path = os.path.join(log_dir_path, "log_" + current_date + ".log")
    
    def tearDown(self):
        if os.path.exists(self.log_file_path):
            os.remove(self.log_file_path)
        else:
            pass          
    
    def check_string_in_log(self, string_to_check):
        return string_to_check in open(self.log_file_path).read()
    
    #TestCase
    def test_init_log_dev_mode(self):
        settings = {
            'log_level'          : 'DEBUG',
            'log_dir'            : '/app/tests/robot/ping_method_robot/log',
            'log_name_date_fmt'  : '%Y-%m-%d',
            'log_msg_fmt'        : '%(asctime)s - PingMethod - %(levelname)-5s - %(message)s',
            'log_date_fmt'       : '%Y-%m-%d %H:%M:%S',
            'log_mode'           : 'development',
        }
        logger = main_method.init_log(settings)
        self.assertEqual(logger.level, 10)
        self.assertEqual(logger.name, 'Ping_method_log')
    
    def test_init_log_prd_mode(self):
        settings = {
            'log_level'          : 'DEBUG',
            'log_dir'            : '/app/tests/robot/ping_method_robot/log',
            'log_name_date_fmt'  : '%Y-%m-%d',
            'log_msg_fmt'        : '%(asctime)s - PingMethod - %(levelname)-5s - %(message)s',
            'log_date_fmt'       : '%Y-%m-%d %H:%M:%S',
            'log_mode'           : 'production',
        }
        logger = main_method.init_log(settings)
        self.assertEqual(logger.level, 10)
        self.assertEqual(logger.name, 'Ping_method_log')

    def test_init_log_no_mode_is_set(self):
        settings = {
            'log_level'          : 'DEBUG',
            'log_dir'            : '/app/tests/robot/ping_method_robot/log',
            'log_name_date_fmt'  : '%Y-%m-%d',
            'log_msg_fmt'        : '%(asctime)s - PingMethod - %(levelname)-5s - %(message)s',
            'log_date_fmt'       : '%Y-%m-%d %H:%M:%S',
            'log_mode'           : None,
        }
        with self.assertRaises(ValueError):
            logger = main_method.init_log(settings)
        
    def test_read_conf(self):
        with self.assertRaises(Exception):
            main_method.read_config("/invalid-path/sample_conf.yaml")
        config_path = '/app/tests/unit_test/test_data/read_conf/sample_conf.yaml'
        conf_dict = main_method.read_config(config_path)
        self.assertTrue(len(conf_dict['url_base']) > 0)
        self.assertTrue(len(conf_dict['asg_file']) > 0)
        self.assertTrue(len(conf_dict['utm_file']) > 0)
        self.assertTrue(len(conf_dict['domain']) > 0)
        self.assertTrue(len(conf_dict['normal']) > 0)
        self.assertTrue(len(conf_dict['abnormal']) > 0)
        self.assertTrue(len(conf_dict['archive']) > 0)
        self.assertTrue(len(conf_dict['log_level']) > 0)
        self.assertTrue(len(conf_dict['log_dir']) > 0)
        self.assertTrue(len(conf_dict['log_msg_fmt']) > 0)
        self.assertTrue(len(conf_dict['log_date_fmt']) > 0)
        self.assertTrue(len(conf_dict['log_mode']) > 0)

    def test_read_utm_file(self):
        with self.assertRaises(Exception):
            main_method.read_utm_file("/invalid-path/sample_utm_ip.csv")
        comp_df = pd.DataFrame({
            'asgname':[
                'asg_003',
                'asg_003',
                'asg_004',
                'asg_005',
            ],
            'ip_address':[
                '192.168.1.3',
                '192.168.1.4',
                '192.168.1.5',
                '',
            ],
        })
        utm_file_path = '/app/tests/unit_test/test_data/read_utm_file/sample_utm_ip.csv'
        df_utm_ip = main_method.read_utm_file(utm_file_path)
        assert_frame_equal(df_utm_ip, comp_df)

    def test_make_asg_list(self):
        with self.assertRaises(Exception):
            main_method.make_asg_list("/invalid-path/sample_center_ASG.lst")
        asg_file_path = '/app/tests/unit_test/test_data/make_asg_list/sample_center_ASG.lst'
        asg_list = main_method.make_asg_list(asg_file_path)
        comp_list = [
            'asg_003',
            'asg_004',
            'asg_005',
        ]
        self.assertEqual(asg_list, comp_list)

    def test_create_iplist_for_each_ASG(self):
        df_utm_ip = pd.DataFrame({
            'asgname':[
                'asg_003',
                'asg_003',
                'asg_004',
            ],
            'ip_address':[
                '192.168.1.3',
                '192.168.1.4',
                '192.168.1.5',
            ],
        })
        asg_name ='asg_003'
        ip_list = main_method.create_iplist_for_each_ASG(df_utm_ip, asg_name)
        comp_list = [
            '192.168.1.3',
            '192.168.1.4',
        ]
        self.assertEqual(ip_list, comp_list)

        asg_name ='asg_004'
        ip_list = main_method.create_iplist_for_each_ASG(df_utm_ip, asg_name)
        comp_list = [
            '192.168.1.5'
        ]
        self.assertEqual(ip_list, comp_list)

    def test_test_create_iplist_for_each_ASG_has_empty_item(self):
        df_utm_ip = pd.DataFrame({
            'asgname':[
                'asg_003',
                'asg_003',
                'asg_004',
            ],
            'ip_address':[
                '192.168.1.3',
                '',
                '192.168.1.5',
            ],
        })

        asg_name ='asg_003'
        ip_list = main_method.create_iplist_for_each_ASG(df_utm_ip, asg_name)
        comp_list = [
            '192.168.1.3'
        ]
        self.assertEqual(ip_list, comp_list)

        asg_name ='asg_004'
        ip_list = main_method.create_iplist_for_each_ASG(df_utm_ip, asg_name)
        comp_list = [
            '192.168.1.5'
        ]
        self.assertEqual(ip_list, comp_list)
    

    @patch('main_method.MultiPing.receive')
    def test_ping_if_rtt_is_999ms_then_result_is_ok(self, mock):
        """
        1.3:999msに設定。成功。
        """
        mock.return_value = ({'192.168.1.3': 0.999}, [])

        print(mock)
        
        ip_addr = ['192.168.1.3']
        res, no_res = main_method.ping(ip_addr, 1)
        print(res)
        self.assertEqual(res, {'192.168.1.3': 999})
        for y in res.keys():
            self.assertGreater(1000, res[y])
        self.assertEqual(no_res, [])

    @patch('main_method.MultiPing.receive')
    def test_ping_if_timeout_has_happened_then_result_is_ng(self, mock):
        """
        1.3:1000msに設定。失敗。
        """
        mock.return_value = ({}, ['192.168.1.3'])
        ip_addr = ['192.168.1.3']
        res, no_res = main_method.ping(ip_addr, 1)
        self.assertEqual(res, {})     
        self.assertEqual(no_res, ['192.168.1.3'])
    

    @patch('main_method.MultiPing.receive')
    def test_ping_if_rtt_is_1000ms_then_result_is_ng(self, mock):
        """
        1.3:1000msに設定するが、タイムアウトにならなかったケース。失敗。
        """
        mock.return_value = ({'192.168.1.3': 1}, [])
        ip_addr = ['192.168.1.3']
        res, no_res = main_method.ping(ip_addr, 1)
        self.assertEqual(res, {})     
        self.assertEqual(no_res, ['192.168.1.3'])  

    @patch('main_method.MultiPing.receive') 
    def test_ping_multi_target_all_ok(self, mock):
        """
        全て全て成功パターン
        未設定IP:192.168.1.3,4,5
        """
        mock.return_value = ({'192.168.1.3': 0.1, '192.168.1.4': 0.2, '192.168.1.5': 0.3}, [])
        ip_addr = ['192.168.1.3', '192.168.1.4', '192.168.1.5']
        res, no_res = main_method.ping(ip_addr, 1)
        responses_addr = []
        for x in res.keys():
            responses_addr.append(x)
        self.assertCountEqual(responses_addr, ['192.168.1.3', '192.168.1.4', '192.168.1.5'])
        self.assertEqual(no_res, [])

    @patch('main_method.MultiPing.receive', return_value=({'192.168.1.3': 0.1, '192.168.1.5': 0.3}, ['192.168.1.4'])) 
    def test_ping_multi_target_mixed_ok_and_ng(self, mock):
        """
        成功、不成功混在パターン
        未設定IP:192.168.1.3,5
        ダウンIP:192.168.1.4
        """
        ip_addr = ['192.168.1.3', '192.168.1.4', '192.168.1.5']
        res, no_res = main_method.ping(ip_addr, 1)
        responses_addr = []
        for x in res.keys():
            responses_addr.append(x)
        self.assertCountEqual(responses_addr, ['192.168.1.3', '192.168.1.5'])
        self.assertEqual(no_res, ['192.168.1.4'])  

    @patch('main_method.MultiPing.receive', return_value=({}, ['192.168.1.3', '192.168.1.4', '192.168.1.5'])) 
    def test_ping_multi_target_all_ng(self, mock):
        """
        全て失敗パターン
        ダウンIP:192.168.1.3, 192.168.1.4, 192.168.1.5
        """
        ip_addr = ['192.168.1.3', '192.168.1.4', '192.168.1.5']
        res, no_res = main_method.ping(ip_addr, 1)
        self.assertEqual(res, {})     
        self.assertCountEqual(no_res, ['192.168.1.3', '192.168.1.4', '192.168.1.5'])

    @patch('main_method.ping')
    def test_create_result_dict_and_list_if_ip_list_is_empty_then_both_result_is_empty(self, mock):
        """
        ip_listが空のパターン(mock関数が一回も呼ばれないことを確認)
        """
        ip_list = []
        asg_name = 'asg_003'
        mock.return_value = ({}, [])
        res_dict, no_res_list = main_method.create_result_dict_and_list(ip_list, asg_name, self.logger)
        self.assertEqual(res_dict, {})
        self.assertEqual(no_res_list, [])
        self.assertTrue(self.check_string_in_log('ERROR - Control ASG name:{} The IP address of the corresponding ASG control UTM does not exist in the list.'.format(asg_name)))
    
    @patch('main_method.ping', return_value=({'192.168.1.3': 0.1}, []))
    def test_create_result_dict_and_list_2(self, mock):
        """
        ip_listに成功ipアドレスが１件のパターン
        """
        ip_list = ['192.168.1.3']
        asg_name = 'asg_003'

        res_dict, no_res_list = main_method.create_result_dict_and_list(ip_list, asg_name, self.logger)
        self.assertEqual(res_dict, {'192.168.1.3': 0.1})
        self.assertEqual(no_res_list, [])  
        self.assertTrue(self.check_string_in_log('INFO  - Control ASG name:asg_003 UTM Address:192.168.1.3 Result:success Response Speed(ms):0.1 Timeout Setting(s):1'))

    @patch('main_method.ping', return_value=({}, ['192.168.1.4']))
    def test_create_result_dict_and_list_3(self, mock):
        """
        ip_listに失敗ipアドレスが１件のパターン
        """
        ip_list = ['192.168.1.4']
        asg_name = 'asg_003'
        res_dict, no_res_list = main_method.create_result_dict_and_list(ip_list, asg_name, self.logger)
        self.assertEqual(no_res_list, ['192.168.1.4'])
        self.assertEqual(res_dict, {}) 
        self.assertTrue(self.check_string_in_log('INFO  - Control ASG name:asg_003 UTM Address:192.168.1.4 Result:failure Response Speed(ms):0 Timeout Setting(s):1'))

    @patch('main_method.ping', return_value=({'192.168.1.3': 0.1}, ['192.168.1.4']))
    def test_create_result_dict_and_list_4(self, mock):
        """
        ip_listに成功ipアドレスが１件、失敗アドレスが1件のパターン
        """
        ip_list = [
            '192.168.1.3',
            '192.168.1.4',
        ]
        asg_name = 'asg_003'
        res_dict, no_res_list = main_method.create_result_dict_and_list(ip_list, asg_name, self.logger)
        self.assertEqual(res_dict, {'192.168.1.3': 0.1})
        self.assertEqual(no_res_list, ['192.168.1.4'])
        self.assertTrue(self.check_string_in_log('INFO  - Control ASG name:asg_003 UTM Address:192.168.1.3 Result:success Response Speed(ms):0.1 Timeout Setting(s):1'))
        self.assertTrue(self.check_string_in_log('INFO  - Control ASG name:asg_003 UTM Address:192.168.1.4 Result:failure Response Speed(ms):0 Timeout Setting(s):1'))

    def test_make_url(self):
        """
        "/test"を引数として渡すと、http://192.168.1.2/testというURLを返す。
        """
        url = main_method.make_url("http://192.168.1.2", "/test")
        self.assertEqual(url, "http://192.168.1.2/apis/test")

    @patch('main_method.requests.get')
    def test_get_domain_id(self, mock):
        """
        ドメイン名を引数として渡すと、ドメインのIDを返す。
        """
        res = requests.Response()
        res._content = '{"results": [ {"id":1}]}'.encode()
        mock.return_value = res
        result = main_method.get_domain_id("secutrityboss", "http://192.168.1.2")
        self.assertEqual(result, 1)

    @patch('main_method.requests.get')
    def test_get_category_id(self, mock):
        """
        カテゴリ名を引数として渡すと、カテゴリのIDを返す。
        """
        res = requests.Response()
        res._content = '{"results": [ {"id":1}]}'.encode()
        mock.return_value = res
        result = main_method.get_category_id("asg_watch", "aaaa", "http://192.168.1.2")
        self.assertEqual(result, 1)
        
    @patch('main_method.requests.get')
    def test_get_product_id(self, mock):
        """
        プロダクト名を引数として渡すと、プロダクトのIDを返す。
        """
        res = requests.Response()
        res._content = '{"results": [ {"id":1}]}'.encode()
        mock.return_value = res
        result = main_method.get_product_id("asg_001", "http://192.168.1.2")
        self.assertEqual(result, 1)
        
    @patch('main_method.requests.patch')       
    def test_change_category_id(self, mock):
        """
        変更対象のプロダクトIDと変更先のカテゴリIDを引数として渡すと、その通りにカテゴリの変更を行う。
        """
        res = requests.Response()
        res.status_code = 200
        mock.return_value = res
        result = main_method.change_category_id(1, 1, "http://192.168.1.2")
        self.assertEqual(result, res)

    @patch('main_method.change_category_id')
    def test_change_category_id_of_each_asg_if_ping_result_has_no_item(self, mock):
        res = requests.Response()
        res.status_code = 200
        mock.return_value = res

        main_method.change_category_id_of_each_asg(1,1,1,1,"http://192.168.1.2","a",0,0, self.logger)
        self.assertTrue(self.check_string_in_log('INFO  - ASG name:a category changed to asg_unwatched'))

    @patch('main_method.change_category_id')
    def test_change_category_id_of_each_asg_if_ping_result_has_at_least_one_success(self, mock):
        res = requests.Response()
        res.status_code = 200
        mock.return_value = res

        main_method.change_category_id_of_each_asg(1,1,1,1,"http://192.168.1.2","a",1,0, self.logger)
        self.assertTrue(self.check_string_in_log('INFO  - ASG name:a category changed to asg_watch'))

    @patch('main_method.change_category_id')
    def test_change_category_id_of_each_asg_if_ping_result_is_all_failure(self, mock):
        res = requests.Response()
        res.status_code = 200
        mock.return_value = res

        main_method.change_category_id_of_each_asg(1,1,1,1,"http://192.168.1.2","a",0,1, self.logger)  
        self.assertTrue(self.check_string_in_log('INFO  - ASG name:a category changed to asg_alert'))

    @patch('main_method.change_category_id')
    def test_change_category_id_of_each_asg_if_ping_result_is_illegal(self, mock):
        res = requests.Response()
        res.status_code = 200
        mock.return_value = res

        with self.assertRaises(Exception):
            main_method.change_category_id_of_each_asg(1,1,1,1,"http://192.168.1.2","a",-1,1, self.logger) 

    @patch('main_method.requests.post')
    def test_send_result(self, mock):
        res = requests.Response()
        res.status_code = 201
        mock.return_value = res
        main_method.send_result(1, '2019-08-19T09:41:57.648193+09:00', 25, 25, "http://192.168.1.2", self.logger)
        params_check = {
            'product'   : 1,
            'datetime'  : '2019-08-19T09:41:57.648193+09:00', 
            'failure'   : 25, 
            'success'   : 25, 
        }      
        self.assertTrue(self.check_string_in_log('INFO  - ' + str(params_check)))

    @patch('main_method.requests.post')
    def test_send_result_return_code_is_not_201(self, mock):
        res = requests.Response()
        res.status_code = 400
        mock.return_value = res
        main_method.send_result(1, '2019-08-19T09:41:57.648193+09:00', 25, 25, "http://192.168.1.2", self.logger)
        self.assertTrue(self.check_string_in_log('ERROR - Registration of the ping transmission result failed'))

if __name__ == '__main__':
    # singletest = unittest.TestSuite()
    # singletest.addTest(TestPing_Main_method('test_send_result_return_code_is_not_201'))
    # unittest.TextTestRunner().run(singletest)
    unittest.main(argv=['first-arg-is-ignored'], exit=False, warnings='ignore')
