import sys
import shutil
import unittest
import os
import ipaddress
import pandas as pd
from datetime import datetime
from glob import glob

sys.path.append("/app/ping/ping_list/")
from UTMPing import UTMPing

CONF_PATH = "/app/ping/ping_list/development/ping_config.yml"


class UTMPingTest(unittest.TestCase):


    def setUp(self):
        self.init_UTMPing()


    def init_UTMPing(self):
        self.objPing = UTMPing(CONF_PATH)
        current_date = datetime.today().strftime("%Y-%m-%d")
        self.log_file = os.path.join(self.objPing.log_path, "log_" + current_date + ".log")
        open(self.log_file, 'w').close()


    def check_string_in_log(self, string_to_check):
        return string_to_check in open(self.log_file).read()


    def is_valid_ipaddress(self, ip_address):
        try:
            ipaddress.IPv4Address(ip_address)
            return True
        except ipaddress.AddressValueError:
            return False


    def check_pinglist(self, list_gss, df_pinglist, cacti_indir_path, exp_cnt):
        df_pinglist.fillna(value='', inplace=True)
        list_ping = df_pinglist['asgname'].tolist()

        # asg list in gss.lst and asg names in pinglist must be the same
        if not set(list_gss) == set(list_ping):
            return False

        for asgname in list_gss:
            df_group = df_pinglist[df_pinglist['asgname'] == asgname].copy()

            # Create a list of IP addresses from pinglist file, without duplicates
            pinglist_list = list(set([x for x in df_group['ip_address'].tolist() if len(str(x).rstrip()) != 0]))
            pinglist_cnt = len(pinglist_list)

            cacti_file_cnt = 0
            cacti_file_path = os.path.join(cacti_indir_path, asgname + ".log")

            if os.path.isfile(cacti_file_path):
                # Open input file if it exists and create a list of IP addresses.
                df = pd.read_csv(cacti_file_path, sep=',', header=None, names=['ip_address', 'hostname', 'ip_and_port', 'datetime'])

                # Remove invalid IP addresses
                df_ipcheck = df[['ip_address']].copy().drop_duplicates()
                df_ipcheck['is_valid'] = [self.is_valid_ipaddress(x) for x in df_ipcheck['ip_address']]
                df_cacti_file = df_ipcheck[df_ipcheck['is_valid'] == True].copy()
                df_cacti_file.drop(columns='is_valid', inplace=True)

                cacti_file_ip_list = list(set(df_cacti_file['ip_address'].tolist()))
                cacti_file_cnt = len(cacti_file_ip_list)

                # check if ip addresses in pinglist exists in cacti file ip list
                if pinglist_cnt > 0:
                    # Return False if IP address from pinglist does not exist in input file
                    for ip_address in pinglist_list:
                        if ip_address not in cacti_file_ip_list:
                            return False

            # If line count is greater than or equal to exp_cnt, then pinglist count should be equal to exp_cnt
            if (cacti_file_cnt >= exp_cnt) and (pinglist_cnt == exp_cnt):
                continue
            # If line count is lesser than exp_cnt, then pinglist count should be equal to line count
            elif (cacti_file_cnt < exp_cnt) and (pinglist_cnt == cacti_file_cnt):
                continue
            else:
                return False

        return True


    def test_read_config(self):
        self.assertTrue(len(self.objPing.read_config(CONF_PATH)) > 0)
        with self.assertRaises(Exception):
            self.objPing.read_config("/non-existent/config-file.yaml")


    def test_set_variables(self):
        self.assertTrue(len(self.objPing.host) > 0)
        self.assertTrue(self.objPing.port > 0)
        self.assertTrue(len(self.objPing.user) > 0)
        self.assertTrue(len(self.objPing.password) > 0)

        self.assertTrue(len(self.objPing.src_dir) > 0)
        self.assertTrue(len(self.objPing.src_file) > 0)
        self.assertTrue(self.objPing.timeout > 0)

        self.assertTrue(len(self.objPing.gss_lst) > 0)
        self.assertTrue(len(self.objPing.indir_cacti) > 0)
        self.assertTrue(len(self.objPing.out_pnglst) > 0)

        self.assertTrue(self.objPing.extracount > 0)
        self.assertTrue(len(self.objPing.in_file_ext) > 0)

        self.assertTrue(len(self.objPing.log_level) > 0)
        self.assertTrue(len(self.objPing.log_path) > 0)


    def test_download_cacti_files(self):

        self.objPing.host = "192.168.56.210"
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("timed out"))

        self.init_UTMPing()
        self.objPing.port = 999
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("Unable to connect to port 999"))    

        self.init_UTMPing()
        self.objPing.user = "invalid_user"
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("Authentication failed.")) 

        self.init_UTMPing()
        self.objPing.password = "invalid_password"
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("Authentication failed.")) 

        self.init_UTMPing()
        self.objPing.src_dir = "/home/notexist/"
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("No such file")) 

        self.init_UTMPing()
        self.objPing.src_file = "invalid-filename"
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("No such file")) 

        self.init_UTMPing()
        self.objPing.timeout = 0
        self.objPing.download_cacti_files(self.objPing.read_gss_lst())
        self.assertTrue(self.check_string_in_log("Operation now in progress")) 

        self.init_UTMPing()
        self.objPing.indir_cacti = "/non-existent-directory/"
        with self.assertRaises(Exception):
            self.objPing.download_cacti_files(self.objPing.read_gss_lst())

        self.init_UTMPing()
        list_gss = []
        with self.assertRaises(Exception):
            self.objPing.download_cacti_files(list_gss)

        self.init_UTMPing()
        self.assertTrue(self.objPing.download_cacti_files(self.objPing.read_gss_lst()))


    def test_pingip_extra(self):
        self.objPing.indir_cacti = "/non-existent-directory/"
        with self.assertRaises(Exception):
            self.objPing.pingip_extra(self.objPing.read_gss_lst())

        self.init_UTMPing()
        list_gss = []
        with self.assertRaises(Exception):
            self.objPing.pingip_extra(list_gss)

        self.init_UTMPing()
        test_dir_path = "/app/ping/ping_list/development/cacti_indir_unit_test"
        if os.path.isdir(test_dir_path):
            shutil.rmtree(test_dir_path)
        os.mkdir(test_dir_path)
        self.objPing.indir_cacti = test_dir_path
        with self.assertRaises(Exception):
            self.objPing.pingip_extra(self.objPing.read_gss_lst())
        if os.path.isdir(test_dir_path):
            shutil.rmtree(test_dir_path)

        self.init_UTMPing()
        list_gss = ["sboss_gss-astaro_v9", "sboss_gss-astaro_v7", "sboss_gss-astaro_v10"]
        with self.assertRaises(Exception):
            self.objPing.pingip_extra(list_gss)

        self.init_UTMPing()
        list_gss = ["sboss_gss-astaro_v2", "sboss_gss-astaro_v3", "sboss_gss-astaro_v4"]
        self.objPing.download_cacti_files(list_gss)
        df_pinglist = self.objPing.pingip_extra(list_gss)
        self.assertTrue(len(df_pinglist) > 0)
        self.assertTrue(self.check_pinglist(list_gss,
                                            df_pinglist,
                                            self.objPing.indir_cacti,
                                            self.objPing.extracount))


    def test_main(self):
        self.init_UTMPing()
        self.objPing.gss_lst = "/app/tests/unit_test/gss.lst"
        self.objPing.main()
        self.assertTrue(os.path.exists(self.objPing.out_pnglst))
        df_pinglist = pd.read_csv(self.objPing.out_pnglst)
        list_gss = ["sboss_gss-astaro_v2", "sboss_gss-astaro_v3", "sboss_gss-astaro_v4"]
        self.assertTrue(self.check_pinglist(list_gss,
                                            df_pinglist,
                                            self.objPing.indir_cacti,
                                            self.objPing.extracount))


if __name__ == '__main__':
    singletest = unittest.TestSuite()
    singletest.addTest(UTMPingTest('test_read_config'))
    singletest.addTest(UTMPingTest('test_set_variables'))
    singletest.addTest(UTMPingTest('test_download_cacti_files'))
    singletest.addTest(UTMPingTest('test_pingip_extra'))
    singletest.addTest(UTMPingTest('test_main'))
    unittest.TextTestRunner().run(singletest)
