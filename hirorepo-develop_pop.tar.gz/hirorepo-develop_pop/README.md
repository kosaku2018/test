# pop_team_epic

## 前提

* DockerとDocker Composeがインストール済み
* pyenvでpython3.7.3がインストール済み
* Visual Studio Codeがインストール済み
* コマンドラインでVisual Studio Codeが起動できる

    https://qiita.com/naru0504/items/c2ed8869ffbf7682cf5c

## 準備

    $ pip install pipenv
    $ pipenv install -d

## 実行例

example.pyは例です。不要になったら削除してください。

    $ make run

## カバレッジレポートの作り方

    $ make unit_test

## ディレクトリ構成

| 名前 | 種別 | 説明 |
|-|-|-|
| README.md | file | このプロジェクトの説明書 |
| Pipfile | file | パケージ管理設定ファイル。pipenv甩 |
| Pipfile.lock | file | 同上 |
| .python-version | file | このプロジェクトで利用するpythonのバージョンを指定する設定ファイル。pyenv向け |
| .gitignore | file | gitで管理しないファイルやディレクトリをを指定する設定ファイル |
| docker-compose.yml | file | このプロジェクトで利用するdocker containerをオーケストレーションするための設定ファイル |
| Makefile | file | 定型作業をまとめたファイル |
| containers/ | directory | このプロジェクトで利用するdocker containerのDockerfileを管理するためのディレクトリ |
| ping/ | directory | Ping管理のソースコードを管理する |
| docs/ | directory | README.md以外のドキュメントを管理する |
| tests/unit_test/ | directory | unit testのコードなどを管理する |
| tests/robot/ | directory | robotframeworkのシナリオなどを管理する。 |
