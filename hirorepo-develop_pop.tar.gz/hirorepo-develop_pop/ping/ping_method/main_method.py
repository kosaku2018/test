#!/usr/bin/env python
# coding: utf-8

import logging 
import os
import sys
import yaml
import pandas as pd
from multiping import MultiPing
from datetime import datetime
import pytz
import json
import requests
import urllib.parse
import urllib.request


def init_log(settings):
    logger = logging.getLogger('Ping_method_log')
    log_level = settings['log_level']
    log_mode = settings['log_mode']
    logger.setLevel(log_level)
    current_date = datetime.today().strftime(settings['log_name_date_fmt'])
    log_format = logging.Formatter(settings['log_msg_fmt'], settings['log_date_fmt'])
    log_handler = None
    if log_mode == "development":
        log_path = settings['log_dir']
        if not os.path.isdir(log_path):
            os.mkdir(log_path)
        log_handler = logging.FileHandler(os.path.join(log_path, 'log_' + current_date + '.log'))
        print(os.path.join(log_path, 'log_' + current_date + '.log'))
    elif log_mode == "production":
        log_handler = logging.StreamHandler(sys.stdout)
    else:
        raise ValueError("Invalid log mode is set.")
    log_handler.setLevel(log_level)
    log_handler.setFormatter(log_format)
    logger.addHandler(log_handler)
    return logger

def read_config(conf_path):
    if not os.path.isfile(conf_path):
        raise ValueError("Settings file: {} does not exist.".format(conf_path))
    with open(conf_path, 'r') as yaml_file:
        return yaml.safe_load(yaml_file)

def read_utm_file(utm_file):
    if not os.path.isfile(utm_file):
        raise ValueError("UTM file: {} does not exist.".format(utm_file))
    df_utm_ip = pd.read_csv(utm_file) 
    df_utm_ip.fillna(value='', inplace=True)
    return df_utm_ip

def make_asg_list(asg_file):
    if not os.path.isfile(asg_file):
        raise ValueError("ASG file: {} does not exist.".format(asg_file))
    list_asg = [line.rstrip('\n') for line in open(asg_file)]
    return list_asg

def create_iplist_for_each_ASG(df_utm_ip, asg_name):
    ip_list_raw = df_utm_ip[df_utm_ip['asgname']==asg_name]['ip_address'].tolist()
    ip_list = [ip_address for ip_address in ip_list_raw if len(str(ip_address)) > 0]
    return ip_list

def ping(list_ip_addr, timeout=1):
    """
    You ping IP addresses in a list
            
    Parameters
    ----------
    list_ip_addr : list
    The list of IP addresses to ping.
    timeout : int
    The number of seconds to regard result as timeout.
            
    Returns
    -------
    result_tuple : tuple
    The result of pinging.
    res is the dict of IP addresses responsed and rtt.(key=address, value=rtt)
    no_res is the list of IP addresses didn't responsed.
    """
    mp = MultiPing(list_ip_addr)
    mp.send()
    res, no_res = mp.receive(timeout)  # rtt returuns by the second
    for ip_addr in list_ip_addr:
        if ip_addr in res.keys():
            rtt_ms = res[ip_addr] * 1000
            timeout_ms = timeout * 1000
            if rtt_ms < timeout_ms:
                res[ip_addr] = round(rtt_ms, 2)
            else:
                no_res.append(ip_addr)
                del res[ip_addr]
    result_tuple = (res, no_res)
    return result_tuple

def create_result_dict_and_list(ip_list, asg_name, logger):
    res_dict = {}
    no_res_list = []
    if len(ip_list) > 0:
        timeout_s = 1
        res_dict, no_res_list = ping(ip_list, timeout=timeout_s)
        for ip_addr in ip_list:
            rtt_ms = 0
            result = 'failure'
            if ip_addr in res_dict.keys():
                rtt_ms = res_dict[ip_addr]
                result = 'success'
            logger.info('Control ASG name:{} UTM Address:{} Result:{} Response Speed(ms):{} Timeout Setting(s):{}'.format(asg_name, ip_addr, result, rtt_ms, timeout_s))            
    else:
        logger.error('Control ASG name:{} The IP address of the corresponding ASG control UTM does not exist in the list.'.format(asg_name))
    result_tuple = (res_dict, no_res_list)
    return result_tuple

def make_url(url_base, path):
    return urllib.parse.urljoin(url_base, 'apis/{}'.format(path))

def get_domain_id(domain_name, url_base):
    url = make_url(url_base, '/domains/')
    res = requests.get(url, params = { 'name': domain_name })
    return res.json()['results'][0]['id']

def get_category_id(domain_id, category_name, url_base):
    url = make_url(url_base, '/categories/')
    res = requests.get(url, params = {'name': category_name, 'domain': domain_id })
    return res.json()['results'][0]['id']
    
def get_product_id(asg_name, url_base):
    url = make_url(url_base, '/products/')
    res = requests.get(url, params = {'name': asg_name})
    return res.json()['results'][0]['id']

def change_category_id(category_id, product_id, url_base):
    params = {
        "category": category_id,
    }
    url = make_url(url_base, '/products/{}/'.format(product_id))
    response = requests.patch(url, json.dumps(params), headers = {'Content-Type': 'application/json'})
    return response

def change_category_id_of_each_asg(normal_id, abnormal_id, archive_id, product_id, url_base, asg_name, success, failure, logger):
    if success == 0 and failure == 0:
        response = change_category_id(archive_id, product_id, url_base)
        if response.status_code == 200:
            logger.info('ASG name:{} category changed to asg_unwatched'.format(asg_name))
    elif success >= 1:
        response = change_category_id(normal_id, product_id, url_base)
        if response.status_code == 200:
            logger.info('ASG name:{} category changed to asg_watch'.format(asg_name))
    elif success == 0 and failure != 0:
        response = change_category_id(abnormal_id, product_id, url_base)
        if response.status_code == 200:
            logger.info('ASG name:{} category changed to asg_alert'.format(asg_name))
    else:
        raise ValueError("Invalid responses.")
        
def send_result(product_id, datetime_cunducted, failure_utm, success_utm, url_base, logger):
    url = make_url(url_base, '/anomalies/')
    params = {
        'product'   : product_id,
        'datetime'  : datetime_cunducted, 
        'failure'   : failure_utm, 
        'success'   : success_utm, 
    }
    logger.info(params)
    response = requests.post(url, json.dumps(params), headers = {'Content-Type': 'application/json'})
    if response.status_code == 201:
        logger.info(str(response.status_code))
        return response
    else:
        logger.error('Registration of the ping transmission result failed')

def main_method(env_name):
    try:
        ping_main_config = os.environ.get(env_name)
        settings = read_config(ping_main_config)
        logger = init_log(settings)
    except Exception as e:
        raise ValueError(e)
    url_base = settings['url_base']
    domain_id = get_domain_id(settings['domain'], url_base)
    normal_id = get_category_id(domain_id, settings['normal'], url_base)
    abnormal_id = get_category_id(domain_id, settings['abnormal'], url_base)
    archive_id = get_category_id(domain_id, settings['archive'], url_base)
    df_utm_ip = read_utm_file(settings['utm_file'])
    list_asg = make_asg_list(settings['asg_file'])
    for asg in list_asg:
        ip_list = create_iplist_for_each_ASG(df_utm_ip, asg)
        res_dict, no_res_list =  create_result_dict_and_list(ip_list, asg, logger)
        jst = pytz.timezone('Asia/Tokyo')
        datetime_cunducted = datetime.now(tz=jst).isoformat()
        success_utm = len(res_dict)
        failure_utm = len(no_res_list)
        product_id = get_product_id(asg, url_base)
        change_category_id_of_each_asg(normal_id, abnormal_id, archive_id, product_id, url_base, asg, success_utm, failure_utm, logger)
        send_result(product_id, datetime_cunducted, failure_utm, success_utm, url_base, logger)
    
#method call fase
if __name__ == '__main__':
    main_method('PING_MAIN_CONFIG')
