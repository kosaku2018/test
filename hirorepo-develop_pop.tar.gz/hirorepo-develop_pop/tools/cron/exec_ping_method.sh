#!/bin/sh
export PATH=/usr/local/bin/:$PATH

cd ~/pop_team_epic/
make exec_ping_method
