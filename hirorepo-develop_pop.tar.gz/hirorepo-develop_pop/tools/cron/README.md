# Crontab Setting

1. crontab -e　コマンドを実行する。
1. 以下の行をコピーしてCronに設定する。(スクリプトのパスを現在のパスに設定する)
1. エラーが発生するとstderr.txtファイルに出力される。
1. 実行のタイミングに応じてCron設定を変更する。
ping送信リスト
`* * * * 0 ~/pop_team_epic/tools/cron/exec_ping_list.sh 2>stderr_ping_list.txt`
ping送信
`0 * * * * ~/pop_team_epic/tools/cron/exec_ping_method.sh 2>stderr_ping_method.txt`
