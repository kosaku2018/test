#!/bin/bash

CMDNAME=`basename $0`

while getopts d:e:f: OPT
do
  case $OPT in
    "d" ) FLG_D="TRUE" ; VALUE_A="$2" VALUE_B="$3" ;;
    "e" ) FLG_E="TRUE" ; VALUE_A="$2" VALUE_B="$3" ;;
    "f" ) FLG_F="TRUE" ; VALUE_A="$2" VALUE_B="$3" ;;
      * ) echo "Usage: $CMDNAME [-d] [url] [ASG名]" 1>&2
          echo "     : $CMDNAME [-e] [url] [ASGファイル]" 1>&2
          echo "     : $CMDNAME [-f] [urlファイル] [ASGファイル]" 1>&2
          exit 1 ;;
  esac
done


if [ "$FLG_D" = "TRUE" ]; then

  URL=$VALUE_A
  ASG_NAME=$VALUE_B

  PID=$(curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id')
  echo "pid:"$PID

  AID=$(curl -s $URL/apis/anomalies/?product=$PID | jq '.results[].id')
  echo "aid:"$AID

  for i in $AID
  do
    echo $i
    curl -v -X DELETE $URL/apis/anomalies/$i/
  done

fi


if [ "$FLG_E" = "TRUE" ]; then

  URL=$VALUE_A
  FILE_ASG=$VALUE_B

  while read row; do

    ASG_NAME=`echo ${row} | cut -d , -f 2`

    PID=$(curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id')
    echo "pid:"$PID

    AID=$(curl -s $URL/apis/anomalies/?product=$PID | jq '.results[].id')

    echo "aid:"$AID

    for i in $AID
    do
        echo $i
        curl -v -X DELETE $URL/apis/anomalies/$i/
    done

  done < $FILE_ASG

fi


if [ "$FLG_F" = "TRUE" ]; then

  URL=$(cat $VALUE_A)
  FILE_ASG=$VALUE_B

  while read row; do

    ASG_NAME=`echo ${row} | cut -d , -f 2`

    PID=$(curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id')
    echo "pid:"$PID

    AID=$(curl -s $URL/apis/anomalies/?product=$PID | jq '.results[].id')

    echo "aid:"$AID

    for i in $AID
    do
        echo $i
        curl -v -X DELETE $URL/apis/anomalies/$i/
    done

  done < $FILE_ASG

fi

exit 0
