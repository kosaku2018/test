#!/bin/bash

#usage,no argument
if [ $# -eq 0 ]; then
  echo "Usage: ./set_cate.sh \"https://securityboss.p.officialreport.net\" \"sboss_gss-astaro_v10\" 7 "  1>&2
  exit 1
fi

URL=$1
ASG_NAME=$2
CATE=$3

PID=$(curl -s $URL/apis/products/?name=$ASG_NAME | jq '.results[].id')
echo "pid:"$PID

#curl -v -X PATCH -H 'Content-Type: application/json' -d '{"category":'$CATE'}' $URL/apis/products/$PID/
curl --dump-header - -X PATCH -H 'Content-Type: application/json' -d '{"category":'$CATE'}' $URL/apis/products/$PID/

